import afl
import sys

afl.init()  # Initialize AFL++

def main():
    """Simulate a buffer overflow in Python."""
    data = sys.stdin.read().strip()

    buffer = bytearray(10)  # Fixed size buffer

    if len(data) > 10:
        print("Buffer overflow detected!")
        sys.exit(1)

    buffer[:len(data)] = data.encode()  # Copy data to buffer safely

    print(f"Processed safely: {data}")

if __name__ == "__main__":
    main()

