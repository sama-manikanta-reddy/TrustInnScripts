import afl
import sys

afl.init()  # Initialize AFL++

def main():
    """Check if input reaches a hidden condition."""
    data = sys.stdin.read().strip()

    if data == "hidden_path":
        print("You discovered the hidden path!")
        sys.exit(1)  # Special exit condition

    print(f"Processed: {data}")

if __name__ == "__main__":
    main()

