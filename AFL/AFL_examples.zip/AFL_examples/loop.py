import afl
import sys

afl.init()  # Initialize AFL++

def main():
    """Cause an infinite loop on specific input."""
    data = sys.stdin.read().strip()

    if data == "loop":
        while True:  # Intentional infinite loop
            pass  

    print(f"Processed: {data}")

if __name__ == "__main__":
    main()

