import afl  # Import AFL++ instrumentation
import sys

afl.init()  # Initialize AFL++ as early as possible

MAX_SIZE = 10**6  # Limit maximum memory allocation (1 million elements)

def main():
    """Reads input from stdin instead of sys.argv for AFL++ fuzzing."""
    try:
        data = sys.stdin.read().strip()  # Read from stdin instead of argv
        size = int(data)  # Convert input to an integer

        # Prevent excessive memory allocation
        if size > MAX_SIZE:
            print("Error: Size too large!")
            sys.exit(1)

        _ = [0] * size  # Memory allocation
        print(f"Created a list of size: {size}")

    except ValueError:
        print("Error: Invalid input, expected an integer.")
        sys.exit(1)
    except MemoryError:
        print("Error: Memory allocation failed!")
        sys.exit(1)

if __name__ == "__main__":
    main()

