import afl
import sys

afl.init()

def process_input():
    """Reads input from stdin and processes it."""
    data = sys.stdin.read()
    
    # Simulating a crash for fuzzing purposes
    if "crash" in data:
        raise ValueError("Triggered crash condition!")

    print(f"Processed: {data}")

if __name__ == "__main__":
    process_input()

