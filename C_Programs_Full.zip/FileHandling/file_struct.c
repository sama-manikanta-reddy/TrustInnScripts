#include <stdio.h>
#include <stdlib.h>
struct Employee { int id; char name[20]; };
int main() {
    struct Employee emp = {1, "John Doe"};
    FILE *file = fopen("emp.dat", "wb");
    fwrite(&emp, sizeof(struct Employee), 1, file);
    fclose(file);
    return 0;
}