#include <stdio.h>
int main() {
    FILE *file = fopen("output.txt", "w");
    if (file) {
        fprintf(file, "Hello, File Handling!\n");
        fclose(file);
    }
    return 0;
}