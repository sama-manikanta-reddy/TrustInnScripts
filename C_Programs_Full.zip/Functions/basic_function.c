#include <stdio.h>
void greet() { printf("Hello, Function!\n"); }
int main() { greet(); return 0; }