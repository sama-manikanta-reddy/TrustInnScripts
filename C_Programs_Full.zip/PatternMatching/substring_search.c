#include <stdio.h>
#include <string.h>
int main() {
    char str[] = "hello world", sub[] = "world";
    if (strstr(str, sub)) printf("Substring found!");
    return 0;
}