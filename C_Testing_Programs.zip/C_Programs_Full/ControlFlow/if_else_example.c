#include <stdio.h>
int main() {
    int num = 10;
    if (num > 5) printf("Greater than 5");
    else printf("Less or equal to 5");
    return 0;
}