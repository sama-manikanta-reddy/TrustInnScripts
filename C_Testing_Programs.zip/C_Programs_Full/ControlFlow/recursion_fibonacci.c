#include <stdio.h>
int fibonacci(int n) { return (n <= 1) ? n : fibonacci(n - 1) + fibonacci(n - 2); }
int main() { printf("%d", fibonacci(6)); return 0; }