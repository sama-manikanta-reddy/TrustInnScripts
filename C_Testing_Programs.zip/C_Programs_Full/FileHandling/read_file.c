#include <stdio.h>
int main() {
    FILE *file = fopen("test.txt", "r");
    char line[100];
    if (file) {
        while (fgets(line, sizeof(line), file)) printf("%s", line);
        fclose(file);
    }
    return 0;
}