// Function Pointer Implementation
#include <stdio.h>

// Function declarations
void add(int a, int b) {
    printf("Sum: %d\n", a + b);
}

void subtract(int a, int b) {
    printf("Difference: %d\n", a - b);
}

// Function that takes a function pointer as an argument
void operate(void (*func)(int, int), int x, int y) {
    func(x, y);
}

// Driver function
int main() {
    void (*func_ptr)(int, int); // Function pointer declaration
    
    func_ptr = add;
    func_ptr(10, 5); // Calls add function
    
    func_ptr = subtract;
    func_ptr(10, 5); // Calls subtract function
    
    printf("Using function pointer as an argument:\n");
    operate(add, 20, 10);
    operate(subtract, 20, 10);
    
    return 0;
}
