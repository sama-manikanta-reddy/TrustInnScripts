// Mutex Example
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_THREADS 3
int counter = 0;
pthread_mutex_t lock;

// Function executed by threads
void* threadFunction(void* arg) {
    pthread_mutex_lock(&lock); // Lock the mutex
    counter++;
    printf("Thread %ld: Counter = %d\n", (long)arg, counter);
    sleep(1);
    pthread_mutex_unlock(&lock); // Unlock the mutex
    return NULL;
}

// Driver function
int main() {
    pthread_t threads[NUM_THREADS];
    pthread_mutex_init(&lock, NULL);
    
    for (long i = 0; i < NUM_THREADS; i++) {
        pthread_create(&threads[i], NULL, threadFunction, (void*)i);
    }
    
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }
    
    pthread_mutex_destroy(&lock);
    return 0;
}

