// Producer-Consumer Problem
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define BUFFER_SIZE 5
int buffer[BUFFER_SIZE];
int count = 0;

pthread_mutex_t mutex;
sem_t empty, full;

void* producer(void* arg) {
    int item = 1;
    while (1) {
        sem_wait(&empty);  // Wait if buffer is full
        pthread_mutex_lock(&mutex);
        buffer[count++] = item;
        printf("Produced: %d\n", item++);
        pthread_mutex_unlock(&mutex);
        sem_post(&full);   // Signal that buffer has data
        sleep(1);
    }
}

void* consumer(void* arg) {
    while (1) {
        sem_wait(&full);   // Wait if buffer is empty
        pthread_mutex_lock(&mutex);
        int item = buffer[--count];
        printf("Consumed: %d\n", item);
        pthread_mutex_unlock(&mutex);
        sem_post(&empty);  // Signal that buffer has space
        sleep(2);
    }
}

int main() {
    pthread_t prod, cons;
    pthread_mutex_init(&mutex, NULL);
    sem_init(&empty, 0, BUFFER_SIZE);
    sem_init(&full, 0, 0);

    pthread_create(&prod, NULL, producer, NULL);
    pthread_create(&cons, NULL, consumer, NULL);
    
    pthread_join(prod, NULL);
    pthread_join(cons, NULL);
    
    pthread_mutex_destroy(&mutex);
    sem_destroy(&empty);
    sem_destroy(&full);
    
    return 0;
}

