// Multithreading with pthreads
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_THREADS 3

// Function executed by threads
void* threadFunction(void* arg) {
    printf("Thread %ld: Running\n", (long)arg);
    sleep(1);
    printf("Thread %ld: Finished\n", (long)arg);
    return NULL;
}

// Driver function
int main() {
    pthread_t threads[NUM_THREADS];
    
    for (long i = 0; i < NUM_THREADS; i++) {
        pthread_create(&threads[i], NULL, threadFunction, (void*)i);
    }
    
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }
    
    return 0;
}

