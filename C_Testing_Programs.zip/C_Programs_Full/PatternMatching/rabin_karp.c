// Rabin-Karp Algorithm Implementation
#include <stdio.h>
#include <string.h>

#define PRIME 101 // A prime number used for hashing

// Rabin-Karp pattern searching algorithm
void rabinKarpSearch(char* text, char* pattern, int d) {
    int N = strlen(text);
    int M = strlen(pattern);
    int h = 1, p = 0, t = 0;
    int i, j;

    // The value of h is "pow(d, M-1) % PRIME"
    for (i = 0; i < M - 1; i++)
        h = (h * d) % PRIME;

    // Calculate the hash value of pattern and first window of text
    for (i = 0; i < M; i++) {
        p = (d * p + pattern[i]) % PRIME;
        t = (d * t + text[i]) % PRIME;
    }

    // Slide the pattern over text one by one
    for (i = 0; i <= N - M; i++) {
        if (p == t) { // Check if hash values match
            for (j = 0; j < M; j++) {
                if (text[i + j] != pattern[j])
                    break;
            }
            if (j == M)
                printf("Pattern found at index %d\n", i);
        }

        // Calculate hash value for next window
        if (i < N - M) {
            t = (d * (t - text[i] * h) + text[i + M]) % PRIME;
            if (t < 0)
                t += PRIME;
        }
    }
}

// Driver function
int main() {
    char text[] = "ABABDABACDABABCABAB";
    char pattern[] = "ABABCABAB";
    int d = 256; // Number of possible characters

    printf("Searching for pattern '%s' in text '%s'\n", pattern, text);
    rabinKarpSearch(text, pattern, d);
    return 0;
}

