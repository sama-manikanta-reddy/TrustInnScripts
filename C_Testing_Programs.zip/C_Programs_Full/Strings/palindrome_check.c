// Palindrome Check Implementation
#include <stdio.h>
#include <string.h>

// Function to check if a string is a palindrome
int isPalindrome(char* str) {
    int left = 0, right = strlen(str) - 1;
    while (left < right) {
        if (str[left] != str[right]) {
            return 0; // Not a palindrome
        }
        left++;
        right--;
    }
    return 1; // Palindrome
}

// Driver function
int main() {
    char str[] = "madam";
    if (isPalindrome(str)) {
        printf("'%s' is a palindrome.\n", str);
    } else {
        printf("'%s' is not a palindrome.\n", str);
    }
    return 0;
}

